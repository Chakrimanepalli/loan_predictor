"""Tests module for loan evaluation system"""
